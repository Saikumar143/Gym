package com.capgemini.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.Customer;
import com.capgemini.exception.BookingException;

@Repository
public class BookingDAOImpl implements IBookingDAO 

{
	@PersistenceContext
	private EntityManager entityManager;

	public BookingDAOImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	//===========================================================================

	@Override
	public int addCustomer(Customer customer) throws BookingException {
		
		int bookingId = -1;
		try 
		{
			entityManager.persist(customer);
			bookingId = customer.getId();
		}
		catch (Exception e) 
		{
			throw new BookingException(e.getMessage());
		}
		return bookingId;
	}

	@Override
	public Customer getCustomer(int id) throws BookingException {
		
		Customer customer = null ;
		
		try 
		{
			customer = entityManager.find(Customer.class, id);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			
			throw new BookingException(e.getMessage());
			
		}
		
		if ( customer == null)
		{
			throw new BookingException("Customer Not Found");
		}
		return customer;
	}

	
	
	
}
